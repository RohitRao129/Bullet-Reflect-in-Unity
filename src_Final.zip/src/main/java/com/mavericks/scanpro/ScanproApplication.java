package com.mavericks.scanpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScanproApplication {


	public static void main(String[] args) {
		SpringApplication.run(ScanproApplication.class, args);
	}

}
