package com.mavericks.scanpro.services;

import org.springframework.beans.factory.annotation.Value;

public class ValidationServiceImpl {

    @Value("${regex.name}")
    private String nameRegex;

    public boolean validateName(String name) {
        return name.matches(nameRegex);
    }
}
