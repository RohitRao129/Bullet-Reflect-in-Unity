package com.mavericks.scanpro.services.interfaces;

public interface RepoService {
}
