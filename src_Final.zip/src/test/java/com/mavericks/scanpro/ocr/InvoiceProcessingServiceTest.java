package com.mavericks.scanpro.ocr;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceProcessingServiceTest {

}